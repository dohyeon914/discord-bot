import discord
from discord import app_commands
from discord.ext import commands
import setting

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"Logged in as {bot.user.name}!")
    await bot.change_presence(
        activity=discord.Game(name=f"{setting.server_name} 서버에서 일")
    )


@bot.event
async def on_member_join(member: discord.Member):
    if member.guild.id == setting.welcome_channel_id:
        channel = member.guild.get_channel(setting.welcome_channel_id)
        if channel:
            embed = discord.Embed(
                title="환영합니다!",
                description=f"{member.mention} 님이 {member.guild.name} 서버에 들어오셨습니다!",
                color=discord.Color.green(),
            )
            embed.set_footer(text="by. dohyeon._.914")
            await channel.send(embed=embed)


@bot.event
async def on_member_remove(member: discord.Member):
    if member.guild.id == setting.goodbye_channel_id:
        channel = member.guild.get_channel(setting.goodbye_channel_id)
        if channel:
            embed = discord.Embed(
                title="잘가요!",
                description=f"{member.mention} 님이 {member.guild.name} 서버에서 나가셨습니다.",
                color=discord.Color.red(),
            )
            embed.set_footer(text="by. dohyeon._.914")
            await channel.send(embed=embed)


@bot.tree.command(name="제작자", description="""이 봇의 모든 저작권은 "도현" 에게 있습니다.""")
async def 제작자(interaction: discord.Interaction):
    await interaction.response.send_message(
        """**`제작자: dohyeon._.914`**\n서버: https://discord.gg/melondata""",
        ephemeral=True,
    )


bot.run(setting.token)
