token = "" # 봇토큰
welcome_channel_id = 1  # 환영 메시지를 보낼 채널 아이디
goodbye_channel_id = 1  # 퇴장 메시지를 보낼 채널 아이디
server_name = "" # 서버이름

# 1 을 서버 아이디로 바꿔주세요!