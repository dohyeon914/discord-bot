import discord
from discord import app_commands
from discord.ext import commands
import pytz
import setting
import sqlite3
from datetime import datetime

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

hello_db = sqlite3.connect("hello.db")
bye_db = sqlite3.connect("bye.db")

with hello_db:
    hello_db.execute(
        "CREATE TABLE IF NOT EXISTS welcome (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)"
    )
with bye_db:
    bye_db.execute(
        "CREATE TABLE IF NOT EXISTS goodbye (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)"
    )


@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"Logged in as {bot.user.name} !")
    await bot.change_presence(
        activity=discord.Game(name=f"{len(bot.guilds)}개의 서버에서 일")
    )

def get_current_time():
    timezone = pytz.timezone("Asia/Seoul")
    return datetime.now(timezone).strftime("%Y-%m-%d %H:%M:%S")


@bot.tree.command(name="환영인사채널", description="[Server Admin] 환영 인사 채널을 설정합니다.")
@app_commands.describe(채널="환영 메시지를 보낼 채널")
async def set_welcome_channel(interaction: discord.Interaction, 채널: discord.TextChannel):
    if not interaction.user.guild_permissions.administrator:
        embed = discord.Embed(
                title="접근 거부",
                description=f"명령어를 사용할 권한이 없습니다.",
                color=discord.Color.red(),
            )
        embed.set_footer(text="by. dohyeon._.914")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    with hello_db:
        hello_db.execute(
            "INSERT OR REPLACE INTO welcome (guild_id, channel_id) VALUES (?, ?)",
            (interaction.guild_id, 채널.id),
        )

    embed = discord.Embed(
        title="설정 완료!",
        description=f"{채널.mention} 채널이 환영인사 채널로 설정되었습니다.",
        color=discord.Color.green(),
    )
    embed.set_footer(text="by. dohyeon._.914")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="퇴장인사채널", description="[Server Admin] 퇴장 인사 채널을 설정합니다.")
@app_commands.describe(채널="퇴장 메시지를 보낼 채널")
async def set_goodbye_channel(interaction: discord.Interaction, 채널: discord.TextChannel):
    if not interaction.user.guild_permissions.administrator:
        embed = discord.Embed(
                title="접근 거부",
                description=f"명령어를 사용할 권한이 없습니다.",
                color=discord.Color.red(),
            )
        embed.set_footer(text="by. dohyeon._.914")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    with bye_db:
        bye_db.execute(
            "INSERT OR REPLACE INTO goodbye (guild_id, channel_id) VALUES (?, ?)",
            (interaction.guild_id, 채널.id),
        )

    embed = discord.Embed(
        title="설정 완료!",
        description=f"{채널.mention} 채널이 퇴장인사 채널로 설정되었습니다.",
        color=discord.Color.green(),
    )
    embed.set_footer(text="by. dohyeon._.914")
    await interaction.response.send_message(embed=embed)


@bot.event
async def on_member_join(member: discord.Member):
    with hello_db:
        result = hello_db.execute(
            "SELECT channel_id FROM welcome WHERE guild_id = ?", (member.guild.id,)
        ).fetchone()

    if result:
        channel = member.guild.get_channel(result[0])
        if channel:
            embed = discord.Embed(
                title="환영합니다!",
                description=f"{member.mention} 님이 {member.guild.name} 서버에 들어오셨습니다!\n\n**서버 입장일**\n**`{get_current_time()}`**",
                color=discord.Color.green(),
            )
            embed.set_footer(text="by. dohyeon._.914")
            await channel.send(embed=embed)


@bot.event
async def on_member_remove(member: discord.Member):
    with bye_db:
        result = bye_db.execute(
            "SELECT channel_id FROM goodbye WHERE guild_id = ?", (member.guild.id,)
        ).fetchone()

    if result:
        channel = member.guild.get_channel(result[0])
        if channel:
            embed = discord.Embed(
                title="잘가요!",
                description=f"{member.mention} 님이 {member.guild.name} 서버에서 나가셨습니다.\n\n**서버 퇴장일**\n**`{get_current_time()}`**",
                color=discord.Color.red(),
            )
            embed.set_footer(text="by. dohyeon._.914")
            await channel.send(embed=embed)


@bot.tree.command(name="서버정리", description="[BotAdmin] 채널이 설정되지 않은 서버에서 봇을 나가게 합니다.")
async def leave_unconfigured_servers(interaction: discord.Interaction):
    if interaction.user.id not in setting.admin_id:
        embed = discord.Embed(
                title="접근 거부",
                description=f"명령어를 사용할 권한이 없습니다.",
                color=discord.Color.red(),
            )
        embed.set_footer(text="by. dohyeon._.914")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    left_servers = 0

    for guild in bot.guilds:
        with hello_db:
            welcome_channel = hello_db.execute(
                "SELECT channel_id FROM welcome WHERE guild_id = ?", (guild.id,)
            ).fetchone()

        with bye_db:
            goodbye_channel = bye_db.execute(
                "SELECT channel_id FROM goodbye WHERE guild_id = ?", (guild.id,)
            ).fetchone()

        if not welcome_channel and not goodbye_channel:
            await guild.leave()
            left_servers += 1

    if left_servers > 0:
        embed = discord.Embed(
            title="정리 완료!",
            description=f"{left_servers}개의 서버에서 나갔습니다.",
            color=discord.Color.green(),
        )
    else:
        embed = discord.Embed(
            title="실패!",
            description="정리할 서버가 없습니다.",
            color=discord.Color.red(),
        )

    embed.set_footer(text="by. dohyeon._.914")
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="제작자", description="""이 봇의 모든 저작권은 "도현" 에게 있습니다.""")
async def 제작자(interaction: discord.Interaction):
    await interaction.response.send_message(
            """**`제작자: dohyeon._.914\n서버: https://discord.gg/melondata`**"""
        , ephemeral=True)

bot.run(setting.token)
