admin_id = [] # 어드민 = 님 아이디
token = "" # 봇토큰