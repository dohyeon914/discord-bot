admin_id = [1259697536378343526] # 어드민 = 님 아이디
token = "MTMxNDgzMDE1ODUyMzUzNTQyMA.GxWDEW.ZzbxbzrX88-S4hhzOP01zR2zTqEiMNa27ksdqE" # 봇토큰